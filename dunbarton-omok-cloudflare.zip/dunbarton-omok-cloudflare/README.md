# 던바튼 오목 Cloudflare 서버
Cloudflare Workers + Durable Objects + WebSocket 기반 실시간 오목 서버.

## 포함 기능
- 방 코드별 Durable Object
- 2인 입장 및 랜덤 선공
- 서버측 착수/턴 검증
- 서버측 5목 승리 판정
- 랜덤 캐릭터 번호 배정
- 재대전 합의
- WebSocket 실시간 상태 동기화

## 배포
Cloudflare에서 GitHub 저장소에 연결하거나 Wrangler로 배포하세요.
