package com.mabisave.automacro;

public class MacroPoint {
    public final float x;
    public final float y;
    public final long delayMs;

    public MacroPoint(float x, float y, long delayMs) {
        this.x = x;
        this.y = y;
        this.delayMs = delayMs;
    }
}
