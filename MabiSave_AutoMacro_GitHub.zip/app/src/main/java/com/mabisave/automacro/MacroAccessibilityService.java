package com.mabisave.automacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import java.util.List;

public class MacroAccessibilityService extends AccessibilityService {

    private static MacroAccessibilityService instance;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    private static boolean running = false;
    private static boolean paused = false;
    private static int pointIndex = 0;
    private static int finishedCycles = 0;
    private static int repeatCount = 0; // 0 = infinite
    private static List<MacroPoint> points;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
        stopMacro();
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        stopMacro();
        super.onDestroy();
    }

    public static boolean isReady() {
        return instance != null;
    }

    public static boolean isRunning() {
        return running;
    }

    public static boolean isPaused() {
        return paused;
    }

    public static String startMacro() {
        if (instance == null) return "접근성 서비스를 먼저 켜세요.";
        points = MacroStore.loadPoints(instance);
        if (points == null || points.isEmpty()) return "등록된 좌표가 없습니다.";

        repeatCount = Math.max(0, MacroStore.loadRepeatCount(instance));
        running = true;
        paused = false;
        pointIndex = 0;
        finishedCycles = 0;
        handler.removeCallbacksAndMessages(null);
        handler.post(stepRunnable);
        return "매크로 시작";
    }

    public static void pauseOrResume() {
        if (!running) return;
        paused = !paused;
        if (!paused) {
            handler.removeCallbacksAndMessages(null);
            handler.post(stepRunnable);
        }
    }

    public static void stopMacro() {
        running = false;
        paused = false;
        pointIndex = 0;
        finishedCycles = 0;
        handler.removeCallbacksAndMessages(null);
    }

    private static final Runnable stepRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running || paused || instance == null || points == null || points.isEmpty()) return;

            MacroPoint p = points.get(pointIndex);

            Path path = new Path();
            path.moveTo(p.x, p.y);

            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 65))
                    .build();

            instance.dispatchGesture(gesture, null, null);

            long wait = Math.max(100L, p.delayMs);
            pointIndex++;

            if (pointIndex >= points.size()) {
                pointIndex = 0;
                finishedCycles++;

                if (repeatCount > 0 && finishedCycles >= repeatCount) {
                    stopMacro();
                    return;
                }
            }

            handler.postDelayed(this, wait);
        }
    };
}
