package com.mabisave.automacro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private final List<MacroPoint> points = new ArrayList<>();
    private LinearLayout pointList;
    private TextView status;
    private EditText xInput;
    private EditText yInput;
    private EditText delayInput;
    private EditText repeatInput;

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setPadding(0, dp(6), 0, dp(6));
        return v;
    }

    private EditText numberBox(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setSingleLine(true);
        e.setPadding(dp(8), dp(6), dp(8), dp(6));
        return e;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        return b;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        points.addAll(MacroStore.loadPoints(this));

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);

        TextView title = text("MabiSave Auto Macro", 25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        root.addView(text("등록한 화면 좌표를 순서대로 자동 탭합니다. 접근성 서비스를 켠 뒤 사용하세요.", 15));

        Button access = button("1. 접근성 서비스 설정 열기");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        status = text("", 15);
        root.addView(status);

        root.addView(text("좌표 추가", 19));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        xInput = numberBox("X");
        yInput = numberBox("Y");
        row1.addView(xInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row1.addView(yInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(row1);

        delayInput = numberBox("이 좌표 탭 후 대기 ms (예: 1000)");
        delayInput.setText("1000");
        root.addView(delayInput);

        Button add = button("좌표 추가");
        add.setOnClickListener(v -> addPoint());
        root.addView(add);

        pointList = new LinearLayout(this);
        pointList.setOrientation(LinearLayout.VERTICAL);
        root.addView(pointList);

        root.addView(text("반복 횟수", 19));
        repeatInput = numberBox("0 = 무한 반복, 1 = 한 번");
        int oldRepeat = MacroStore.loadRepeatCount(this);
        repeatInput.setText(String.valueOf(oldRepeat));
        root.addView(repeatInput);

        Button saveRepeat = button("반복 횟수 저장");
        saveRepeat.setOnClickListener(v -> saveRepeat());
        root.addView(saveRepeat);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);

        Button start = button("▶ 시작");
        start.setOnClickListener(v -> {
            saveRepeat();
            String msg = MacroAccessibilityService.startMacro();
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            updateStatus();
        });

        Button pause = button("⏸ 일시정지 / 계속");
        pause.setOnClickListener(v -> {
            MacroAccessibilityService.pauseOrResume();
            updateStatus();
        });

        Button stop = button("■ 정지");
        stop.setOnClickListener(v -> {
            MacroAccessibilityService.stopMacro();
            updateStatus();
        });

        Button clear = button("전체 좌표 삭제");
        clear.setOnClickListener(v -> {
            MacroAccessibilityService.stopMacro();
            points.clear();
            MacroStore.savePoints(this, points);
            renderPoints();
            updateStatus();
        });

        controls.addView(start);
        controls.addView(pause);
        controls.addView(stop);
        controls.addView(clear);
        root.addView(controls);

        root.addView(text(
                "사용 팁: 개발자 옵션의 '포인터 위치'를 잠깐 켜면 화면 X/Y 좌표를 확인하기 쉽습니다. " +
                "작업이 끝나면 포인터 위치는 다시 꺼두세요.", 14));

        setContentView(scroll);
        renderPoints();
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void addPoint() {
        try {
            float x = Float.parseFloat(xInput.getText().toString().trim());
            float y = Float.parseFloat(yInput.getText().toString().trim());
            long delay = Long.parseLong(delayInput.getText().toString().trim());
            delay = Math.max(100L, delay);
            points.add(new MacroPoint(x, y, delay));
            MacroStore.savePoints(this, points);
            xInput.setText("");
            yInput.setText("");
            renderPoints();
        } catch (Exception e) {
            Toast.makeText(this, "X, Y, 대기시간을 숫자로 입력하세요.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveRepeat() {
        try {
            int repeat = Integer.parseInt(repeatInput.getText().toString().trim());
            MacroStore.saveRepeatCount(this, Math.max(0, repeat));
        } catch (Exception e) {
            MacroStore.saveRepeatCount(this, 0);
            repeatInput.setText("0");
        }
    }

    private void renderPoints() {
        pointList.removeAllViews();

        if (points.isEmpty()) {
            pointList.addView(text("등록된 좌표 없음", 14));
            return;
        }

        for (int i = 0; i < points.size(); i++) {
            final int index = i;
            MacroPoint p = points.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView label = text(
                    (i + 1) + ". X=" + Math.round(p.x) +
                            "  Y=" + Math.round(p.y) +
                            "  대기=" + p.delayMs + "ms", 14);

            Button remove = button("삭제");
            remove.setOnClickListener(v -> {
                MacroAccessibilityService.stopMacro();
                points.remove(index);
                MacroStore.savePoints(this, points);
                renderPoints();
                updateStatus();
            });

            row.addView(label, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            row.addView(remove);
            pointList.addView(row);
        }
    }

    private void updateStatus() {
        String service = MacroAccessibilityService.isReady() ? "접근성: 연결됨" : "접근성: 꺼짐";
        String state;
        if (MacroAccessibilityService.isRunning()) {
            state = MacroAccessibilityService.isPaused() ? "상태: 일시정지" : "상태: 실행 중";
        } else {
            state = "상태: 정지";
        }
        status.setText(service + "   |   " + state + "   |   좌표 " + points.size() + "개");
    }
}
