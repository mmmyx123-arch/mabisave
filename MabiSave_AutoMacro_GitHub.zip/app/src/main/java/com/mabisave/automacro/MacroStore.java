package com.mabisave.automacro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class MacroStore {
    private static final String PREF = "macro_store";
    private static final String KEY_POINTS = "points";
    private static final String KEY_REPEAT = "repeat_count";

    private MacroStore() {}

    public static List<MacroPoint> loadPoints(Context context) {
        ArrayList<MacroPoint> result = new ArrayList<>();
        String raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(KEY_POINTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                result.add(new MacroPoint(
                        (float) o.optDouble("x", 0),
                        (float) o.optDouble("y", 0),
                        Math.max(100L, o.optLong("delay", 1000L))
                ));
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static void savePoints(Context context, List<MacroPoint> points) {
        JSONArray arr = new JSONArray();
        try {
            for (MacroPoint p : points) {
                JSONObject o = new JSONObject();
                o.put("x", p.x);
                o.put("y", p.y);
                o.put("delay", p.delayMs);
                arr.put(o);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY_POINTS, arr.toString()).apply();
    }

    public static int loadRepeatCount(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getInt(KEY_REPEAT, 0);
    }

    public static void saveRepeatCount(Context context, int count) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putInt(KEY_REPEAT, count).apply();
    }
}
