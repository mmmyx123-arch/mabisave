plugins {
    id("com.android.application")
}

android {
    namespace = "com.mabisave.automacro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mabisave.automacro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
