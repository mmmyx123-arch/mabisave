# MabiSave Auto Macro

Android AccessibilityService를 이용해 사용자가 직접 등록한 좌표를 순서대로 탭하는 간단한 자동화 앱입니다.

## 기능
- 좌표 여러 개 등록/삭제
- 좌표별 대기시간(ms)
- 반복 횟수 지정
- `0` 입력 시 무한 반복
- 시작 / 일시정지 / 계속 / 정지
- 설정 저장
- Android 8.0(API 26) 이상
- GitHub Actions에서 자동으로 debug APK 빌드

## GitHub에서 APK 만들기
1. 이 ZIP을 압축 해제합니다.
2. ZIP 안의 파일과 폴더를 저장소 **루트**에 모두 업로드합니다.
   - `.github`
   - `app`
   - `build.gradle.kts`
   - `settings.gradle.kts`
   - `README.md`
3. GitHub 저장소의 **Actions** 탭을 엽니다.
4. `Build Android APK` 실행이 끝나면 해당 실행 결과를 엽니다.
5. 아래 **Artifacts**의 `MabiSave-AutoMacro-APK`를 받습니다.
6. ZIP 안의 `app-debug.apk`가 설치 파일입니다.

## 앱 사용
1. 앱 실행
2. `접근성 서비스 설정 열기`
3. `MabiSave Auto Macro` 접근성 서비스 허용
4. X/Y 좌표와 대기시간 등록
5. 반복 횟수 저장 (`0` = 무한)
6. 시작
7. 대상 앱으로 이동

화면 좌표 확인이 필요하면 Android 개발자 옵션의 `포인터 위치` 기능을 잠깐 사용할 수 있습니다.
