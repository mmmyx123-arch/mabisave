# MabiSave Auto Macro v3.1

V3 빌드 오류 수정판.

수정:
- MediaProjectionManager import 누락 수정
- Android 최신 버전용 MediaProjection callback 추가
- 버전 3.1

기능:
- 다른 앱 위 플로팅 패널
- 이미지 검색
- 검색 간격 직접 설정
- 반복 횟수 설정
- 0 = 무한 반복
- 성공/실패 카운트와 실시간 로그
- 이미지 발견 시 자동 탭
