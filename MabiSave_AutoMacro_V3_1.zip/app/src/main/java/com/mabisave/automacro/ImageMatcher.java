package com.mabisave.automacro;

import android.graphics.Bitmap;
import android.graphics.Point;

public final class ImageMatcher {

    private ImageMatcher(){}

    private static int gray(int c) {
        int r = (c >> 16) & 255;
        int g = (c >> 8) & 255;
        int b = c & 255;
        return (r * 30 + g * 59 + b * 11) / 100;
    }

    public static Point find(Bitmap screen, Bitmap templ, double threshold) {
        if (screen == null || templ == null) return null;

        int sw = screen.getWidth(), sh = screen.getHeight();
        int tw = templ.getWidth(), th = templ.getHeight();

        if (tw < 4 || th < 4 || tw > sw || th > sh) return null;

        // 속도 우선: 템플릿 자체 샘플 간격
        int sample = Math.max(2, Math.min(tw, th) / 24);
        int step = Math.max(2, sample);

        double allowed = (1.0 - threshold) * 255.0;
        Point best = null;
        double bestErr = Double.MAX_VALUE;

        for (int y = 0; y <= sh - th; y += step) {
            for (int x = 0; x <= sw - tw; x += step) {
                long sum = 0;
                int n = 0;
                boolean abort = false;

                for (int ty = 0; ty < th; ty += sample) {
                    for (int tx = 0; tx < tw; tx += sample) {
                        int a = gray(screen.getPixel(x + tx, y + ty));
                        int b = gray(templ.getPixel(tx, ty));
                        sum += Math.abs(a - b);
                        n++;

                        if (n > 24 && (sum / (double)n) > allowed * 1.6) {
                            abort = true;
                            break;
                        }
                    }
                    if (abort) break;
                }

                if (!abort && n > 0) {
                    double err = sum / (double)n;
                    if (err < bestErr) {
                        bestErr = err;
                        best = new Point(x + tw/2, y + th/2);
                    }
                }
            }
        }

        return bestErr <= allowed ? best : null;
    }
}
