package com.mabisave.automacro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.InputStream;

public final class TemplateStore {
    private static Uri uri;

    private TemplateStore(){}

    public static void setUri(Uri u) {
        uri = u;
    }

    public static Uri getUri() {
        return uri;
    }

    public static Bitmap load(Context c) {
        if (uri == null) return null;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }
}
