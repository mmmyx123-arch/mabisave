package com.mabisave.automacro;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.*;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class OverlayService extends Service {

    private WindowManager wm;
    private View panel;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean looping = false;
    private long intervalMs = 1300L;
    private int repeatLimit = 0; // 0 = infinite
    private int executed = 0;
    private int successCount = 0;
    private int failCount = 0;
    private double threshold = 0.86;

    private EditText intervalInput;
    private EditText repeatInput;
    private TextView logView;
    private TextView counterView;
    private Button loopButton;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12,12,12,12);
        box.setBackgroundColor(0xE6202124);

        TextView title = new TextView(this);
        title.setText("MabiSave V3");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(15);
        title.setPadding(8,8,8,8);
        box.addView(title);

        TextView intervalLabel = whiteText("검색 간격(ms)");
        box.addView(intervalLabel);

        intervalInput = new EditText(this);
        intervalInput.setText("1300");
        intervalInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        intervalInput.setTextColor(0xFFFFFFFF);
        intervalInput.setHintTextColor(0xFFBBBBBB);
        intervalInput.setHint("예: 1000");
        box.addView(intervalInput);

        TextView repeatLabel = whiteText("반복 횟수 (0 = 무한)");
        box.addView(repeatLabel);

        repeatInput = new EditText(this);
        repeatInput.setText("0");
        repeatInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        repeatInput.setTextColor(0xFFFFFFFF);
        repeatInput.setHintTextColor(0xFFBBBBBB);
        repeatInput.setHint("0 = 무한");
        box.addView(repeatInput);

        Button once = new Button(this);
        once.setText("이미지 1회 찾기");
        once.setOnClickListener(v -> {
            applySettings();
            scanOnce(false);
        });
        box.addView(once);

        loopButton = new Button(this);
        loopButton.setText("무한/반복 시작");
        loopButton.setOnClickListener(v -> startLoop());
        box.addView(loopButton);

        Button pause = new Button(this);
        pause.setText("일시정지");
        pause.setOnClickListener(v -> {
            looping = false;
            handler.removeCallbacks(loopTask);
            addLog("일시정지");
            updateCounters();
        });
        box.addView(pause);

        Button reset = new Button(this);
        reset.setText("로그/카운트 초기화");
        reset.setOnClickListener(v -> {
            executed = successCount = failCount = 0;
            logView.setText("");
            addLog("초기화 완료");
            updateCounters();
        });
        box.addView(reset);

        counterView = whiteText("");
        box.addView(counterView);

        TextView logTitle = whiteText("성공/실패 로그");
        logTitle.setTextSize(13);
        box.addView(logTitle);

        logView = new TextView(this);
        logView.setTextColor(0xFFFFFFFF);
        logView.setTextSize(12);
        logView.setMinLines(5);
        logView.setMaxLines(8);
        logView.setPadding(6,6,6,6);
        logView.setBackgroundColor(0x552F3136);
        box.addView(logView, new LinearLayout.LayoutParams(dp(260), dp(150)));

        Button close = new Button(this);
        close.setText("닫기");
        close.setOnClickListener(v -> stopSelf());
        box.addView(close);

        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 20;
        lp.y = 180;

        panel = box;
        wm.addView(panel, lp);

        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = e.getRawX(); sy = e.getRawY();
                    ox = lp.x; oy = lp.y;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = ox + (int)(e.getRawX() - sx);
                    lp.y = oy + (int)(e.getRawY() - sy);
                    wm.updateViewLayout(panel, lp);
                    return true;
                }
                return true;
            }
        });

        addLog("플로팅 패널 시작");
        updateCounters();
    }

    private TextView whiteText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(12);
        return t;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void applySettings() {
        try {
            intervalMs = Math.max(200L, Long.parseLong(intervalInput.getText().toString().trim()));
        } catch (Exception e) {
            intervalMs = 1300L;
            intervalInput.setText("1300");
        }

        try {
            repeatLimit = Math.max(0, Integer.parseInt(repeatInput.getText().toString().trim()));
        } catch (Exception e) {
            repeatLimit = 0;
            repeatInput.setText("0");
        }
    }

    private void startLoop() {
        applySettings();

        if (!ScreenCaptureService.isReady()) {
            toast("화면 캡처 권한을 먼저 시작하세요.");
            addLog("실패: 화면 캡처 서비스 꺼짐");
            return;
        }
        if (!MacroAccessibilityService.isReady()) {
            toast("접근성 서비스를 먼저 켜세요.");
            addLog("실패: 접근성 서비스 꺼짐");
            return;
        }
        if (TemplateStore.getUri() == null) {
            toast("찾을 이미지를 먼저 선택하세요.");
            addLog("실패: 찾을 이미지 없음");
            return;
        }

        executed = 0;
        successCount = 0;
        failCount = 0;
        looping = true;
        handler.removeCallbacks(loopTask);
        addLog(repeatLimit == 0
                ? "무한 반복 시작 / 간격 " + intervalMs + "ms"
                : "반복 " + repeatLimit + "회 시작 / 간격 " + intervalMs + "ms");
        handler.post(loopTask);
    }

    private void scanOnce(boolean fromLoop) {
        if (!ScreenCaptureService.isReady()) {
            onFailure("화면 캡처 준비 안 됨", fromLoop);
            return;
        }
        if (!MacroAccessibilityService.isReady()) {
            onFailure("접근성 서비스 꺼짐", fromLoop);
            return;
        }

        Bitmap screen = ScreenCaptureService.latestBitmap();
        Bitmap templ = TemplateStore.load(this);

        if (templ == null) {
            if (screen != null) screen.recycle();
            onFailure("찾을 이미지 없음", fromLoop);
            return;
        }

        if (screen == null) {
            templ.recycle();
            onFailure("화면 캡처 실패", fromLoop);
            return;
        }

        panel.setVisibility(View.INVISIBLE);

        new Thread(() -> {
            Point p = ImageMatcher.find(screen, templ, threshold);
            screen.recycle();
            templ.recycle();

            handler.post(() -> {
                panel.setVisibility(View.VISIBLE);

                if (p != null) {
                    boolean tapped = MacroAccessibilityService.tap(p.x, p.y);
                    if (tapped) {
                        successCount++;
                        addLog("성공: 이미지 발견 → 탭 (" + p.x + ", " + p.y + ")");
                    } else {
                        failCount++;
                        addLog("실패: 이미지 발견했지만 탭 실패");
                    }
                } else {
                    failCount++;
                    addLog("실패: 이미지 미발견");
                }

                executed++;
                updateCounters();

                if (fromLoop) {
                    if (repeatLimit > 0 && executed >= repeatLimit) {
                        looping = false;
                        addLog("반복 완료");
                        updateCounters();
                    } else if (looping) {
                        handler.postDelayed(loopTask, intervalMs);
                    }
                }
            });
        }).start();
    }

    private void onFailure(String reason, boolean fromLoop) {
        failCount++;
        executed++;
        addLog("실패: " + reason);
        updateCounters();

        if (fromLoop) {
            if (repeatLimit > 0 && executed >= repeatLimit) {
                looping = false;
                addLog("반복 완료");
            } else if (looping) {
                handler.postDelayed(loopTask, intervalMs);
            }
        }
    }

    private final Runnable loopTask = new Runnable() {
        @Override public void run() {
            if (!looping) return;
            scanOnce(true);
        }
    };

    private void updateCounters() {
        if (counterView == null) return;
        String mode = repeatLimit == 0 ? "무한" : String.valueOf(repeatLimit);
        counterView.setText(
                "상태: " + (looping ? "실행 중" : "정지") +
                " | 반복: " + mode +
                "\n실행 " + executed +
                " / 성공 " + successCount +
                " / 실패 " + failCount
        );
    }

    private void addLog(String msg) {
        if (logView == null) return;
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String old = logView.getText().toString();
        String line = "[" + time + "] " + msg;
        String combined = line + (old.isEmpty() ? "" : "\n" + old);

        String[] lines = combined.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 8);
        for (int i=0; i<max; i++) {
            if (i>0) sb.append("\n");
            sb.append(lines[i]);
        }
        logView.setText(sb.toString());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        looping = false;
        handler.removeCallbacksAndMessages(null);
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
