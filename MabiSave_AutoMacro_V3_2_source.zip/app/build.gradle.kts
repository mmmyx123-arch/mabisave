plugins {
    id("com.android.application")
}

android {
    namespace = "com.mabisave.automacro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mabisave.automacro"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "3.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
