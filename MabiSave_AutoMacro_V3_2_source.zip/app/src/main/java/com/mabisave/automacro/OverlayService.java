package com.mabisave.automacro;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.*;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class OverlayService extends Service {

    private static OverlayService instance;
    private WindowManager wm;
    private WindowManager.LayoutParams windowLayout;
    private ScrollView expandedPanel;
    private LinearLayout compactPanel;
    private TextView compactStatus;
    private boolean compact;
    public static boolean isActive() {return instance!=null && (instance.looping||instance.busy||instance.selecting);}
    public static void saveIdleSettings() {if(instance!=null && !isActive())instance.applySettings();}
    public static void reloadPreset() {
        if(instance==null)return;
        OverlayService s=instance;s.stopRun();
        s.images=TemplateStore.list(s);s.stepIndex=s.cycles=s.executed=s.successCount=s.failCount=0;
        android.content.SharedPreferences p=s.getSharedPreferences("macro",0);
        s.intervalInput.setText(p.getString("interval","1300"));s.repeatInput.setText(p.getString("repeat","0"));
        s.addLog("프리셋 불러오기 완료");s.updateCounters();
    }
    private View panel;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean looping = false;
    private boolean busy = false;
    private final java.util.concurrent.ExecutorService worker = java.util.concurrent.Executors.newSingleThreadExecutor();
    private java.util.concurrent.Future<?> searchJob;
    private int generation = 0;
    private int stepIndex = 0;
    private long stepStarted;
    private Runnable timeoutTask;
    private StepSettings activeStep;
    private boolean selecting;
    private SelectionOverlay selector;
    private Bitmap selectionBitmap;
    private int cycles = 0;
    private java.util.List<android.net.Uri> images = new java.util.ArrayList<>();
    private SeekBar accuracy;
    private TextView accuracyLabel;
    private long intervalMs = 1300L;
    private int repeatLimit = 0; // 0 = infinite
    private int executed = 0;
    private int successCount = 0;
    private int failCount = 0;
    private double threshold = 0.86;

    private EditText intervalInput;
    private EditText repeatInput;
    private TextView logView;
    private TextView counterView;
    private Button loopButton;

    @Override
    public void onCreate() {
        super.onCreate();
        instance=this;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12,12,12,12);
        box.setBackgroundColor(0xE6202124);

        TextView title = new TextView(this);
        title.setText("MabiSave 3.4 · 순차 실행");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(15);
        title.setPadding(8,8,8,8);
        box.addView(title);
        Button fold = new Button(this);fold.setText("작은 패널로 접기");
        fold.setOnClickListener(v -> setCompact(true));box.addView(fold);

        TextView intervalLabel = whiteText("검색 간격(ms)");
        box.addView(intervalLabel);

        intervalInput = new EditText(this);
        intervalInput.setText("1300");
        intervalInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        intervalInput.setTextColor(0xFFFFFFFF);
        intervalInput.setHintTextColor(0xFFBBBBBB);
        intervalInput.setHint("예: 1000");
        box.addView(intervalInput);

        TextView repeatLabel = whiteText("반복 횟수 (0 = 무한)");
        box.addView(repeatLabel);

        repeatInput = new EditText(this);
        repeatInput.setText("0");
        repeatInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        repeatInput.setTextColor(0xFFFFFFFF);
        repeatInput.setHintTextColor(0xFFBBBBBB);
        repeatInput.setHint("0 = 무한");
        box.addView(repeatInput);

        accuracyLabel = whiteText("정확도: 86%");

        accuracy = new SeekBar(this);
        accuracy.setMax(30);
        accuracy.setProgress(16);
        accuracy.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) { accuracyLabel.setText("정확도: " + (70+v) + "%"); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        android.content.SharedPreferences prefs = getSharedPreferences("macro", 0);
        intervalInput.setText(prefs.getString("interval", "1300"));
        repeatInput.setText(prefs.getString("repeat", "0"));
        accuracy.setProgress(prefs.getInt("accuracy", 86)-70);

        Button crop = new Button(this); crop.setText("화면에서 이미지 잘라 추가");
        crop.setOnClickListener(v -> selectRegion(false)); box.addView(crop);
        Button region = new Button(this); region.setText("현재 단계 검색 영역 지정");
        region.setOnClickListener(v -> selectRegion(true)); box.addView(region);
        TextView stageTip = whiteText("단계별 정확도·대기·제한시간은 앱 이미지 목록에서 설정합니다.");
        box.addView(stageTip);

        Button once = new Button(this);
        once.setText("현재 단계 1회 실행");
        once.setOnClickListener(v -> {
            if (busy || looping || selecting) return;
            applySettings();
            images = TemplateStore.list(this);
            if (stepIndex >= images.size()) stepIndex = 0;
            scanOnce(false);
        });
        box.addView(once);

        loopButton = new Button(this);
        loopButton.setText("무한/반복 시작");
        loopButton.setOnClickListener(v -> startLoop());
        box.addView(loopButton);

        Button pause = new Button(this);
        pause.setText("정지");
        pause.setOnClickListener(v -> {
            stopRun();
            addLog("정지 · 다시 시작하면 1번부터 실행");
            updateCounters();
        });
        box.addView(pause);

        Button reset = new Button(this);
        reset.setText("로그/카운트 초기화");
        reset.setOnClickListener(v -> {
            stopRun();
            executed = successCount = failCount = stepIndex = cycles = 0;
            logView.setText("");
            addLog("초기화 완료");
            updateCounters();
        });
        box.addView(reset);

        counterView = whiteText("");
        box.addView(counterView);

        TextView logTitle = whiteText("성공/실패 로그");
        logTitle.setTextSize(13);
        box.addView(logTitle);

        logView = new TextView(this);
        logView.setTextColor(0xFFFFFFFF);
        logView.setTextSize(12);
        logView.setMinLines(5);
        logView.setMaxLines(8);
        logView.setPadding(6,6,6,6);
        logView.setBackgroundColor(0x552F3136);
        box.addView(logView, new LinearLayout.LayoutParams(dp(260), dp(150)));

        Button close = new Button(this);
        close.setText("닫기");
        close.setOnClickListener(v -> stopSelf());
        box.addView(close);

        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 20;
        lp.y = 180;

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        lp.width = dp(290);
        lp.height = Math.min(dp(640), getResources().getDisplayMetrics().heightPixels - dp(64));
        lp.y = dp(32);
        expandedPanel=scroll;
        android.widget.FrameLayout frame=new android.widget.FrameLayout(this);
        frame.addView(scroll,new android.widget.FrameLayout.LayoutParams(-1,-1));
        compactPanel=new LinearLayout(this);compactPanel.setOrientation(LinearLayout.VERTICAL);
        compactPanel.setPadding(dp(6),dp(4),dp(6),dp(4));compactPanel.setBackgroundColor(0xEF202124);
        TextView miniTitle=whiteText("MabiSave · 드래그로 이동");compactPanel.addView(miniTitle);
        compactStatus=whiteText("");compactPanel.addView(compactStatus);
        LinearLayout controls=new LinearLayout(this);
        Button miniStart=new Button(this);miniStart.setText("시작");miniStart.setTextSize(12);
        miniStart.setOnClickListener(v -> startLoop());controls.addView(miniStart,new LinearLayout.LayoutParams(0,dp(48),1));
        Button miniStop=new Button(this);miniStop.setText("정지");miniStop.setTextSize(12);
        miniStop.setOnClickListener(v -> {stopRun();addLog("정지");updateCounters();});
        controls.addView(miniStop,new LinearLayout.LayoutParams(0,dp(48),1));
        Button expand=new Button(this);expand.setText("펼침");expand.setTextSize(12);
        expand.setOnClickListener(v -> setCompact(false));controls.addView(expand,new LinearLayout.LayoutParams(0,dp(48),1));
        compactPanel.addView(controls);
        frame.addView(compactPanel,new android.widget.FrameLayout.LayoutParams(-1,-2));
        compactPanel.setVisibility(View.GONE);
        panel=frame;windowLayout=lp;
        View.OnFocusChangeListener focusListener = (v, focused) -> {
            if (focused) { lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; wm.updateViewLayout(panel, lp); }
        };
        intervalInput.setOnFocusChangeListener(focusListener);
        repeatInput.setOnFocusChangeListener(focusListener);
        wm.addView(panel, lp);

        View.OnTouchListener dragListener=new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = e.getRawX(); sy = e.getRawY();
                    ox = lp.x; oy = lp.y;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = Math.max(0, Math.min(getResources().getDisplayMetrics().widthPixels - lp.width, ox + (int)(e.getRawX() - sx)));
                    lp.y = Math.max(0, Math.min(getResources().getDisplayMetrics().heightPixels - dp(80), oy + (int)(e.getRawY() - sy)));
                    wm.updateViewLayout(panel, lp);
                    return true;
                }
                return true;
            }
        };
        title.setOnTouchListener(dragListener);miniTitle.setOnTouchListener(dragListener);
        setCompact(prefs.getBoolean("compact",false));
        addLog("플로팅 패널 시작");
        updateCounters();
    }

    private void setCompact(boolean value) {
        compact=value;
        if(value)applySettings();
        expandedPanel.setVisibility(value ? View.GONE : View.VISIBLE);
        compactPanel.setVisibility(value ? View.VISIBLE : View.GONE);
        windowLayout.width=Math.min(dp(value?240:290),getResources().getDisplayMetrics().widthPixels);
        windowLayout.height=value ? WindowManager.LayoutParams.WRAP_CONTENT : Math.min(dp(640),getResources().getDisplayMetrics().heightPixels-dp(64));
        windowLayout.x=Math.max(0,Math.min(windowLayout.x,getResources().getDisplayMetrics().widthPixels-windowLayout.width));
        windowLayout.y=Math.max(0,Math.min(windowLayout.y,getResources().getDisplayMetrics().heightPixels-dp(value?110:160)));
        wm.updateViewLayout(panel,windowLayout);
        getSharedPreferences("macro",0).edit().putBoolean("compact",value).apply();
    }

    private TextView whiteText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(12);
        return t;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void selectRegion(boolean searchArea) {
        if (busy || looping || selecting) { toast("실행을 정지한 뒤 선택하세요"); return; }
        images=TemplateStore.list(this);
        if(searchArea && images.isEmpty()) {toast("이미지를 먼저 등록하세요");return;}
        if(!ScreenCaptureService.isReady()) {toast("화면 검색 권한을 먼저 시작하세요");return;}
        if(stepIndex>=images.size()) stepIndex=0;
        final android.net.Uri target=searchArea ? images.get(stepIndex) : null;
        selecting=true;
        panel.setVisibility(View.INVISIBLE);
        Bitmap old=ScreenCaptureService.latestBitmap();if(old!=null)old.recycle();
        handler.postDelayed(() -> {
            selectionBitmap=ScreenCaptureService.latestBitmap();
            if(selectionBitmap==null) {selecting=false;panel.setVisibility(View.VISIBLE);toast("새 화면을 받지 못했습니다. 다시 시도하세요");return;}
            try {
                selector=new SelectionOverlay(this,selectionBitmap,searchArea ? "검색 영역" : "찾을 이미지",new SelectionOverlay.Result() {
                    public void selected(android.graphics.Rect rect) {
                        try {
                            if(searchArea) {
                                StepSettings config=StepSettings.load(OverlayService.this,target);
                                config.left=rect.left/(float)selectionBitmap.getWidth();config.right=rect.right/(float)selectionBitmap.getWidth();
                                config.top=rect.top/(float)selectionBitmap.getHeight();config.bottom=rect.bottom/(float)selectionBitmap.getHeight();
                                config.save(OverlayService.this,target);addLog("단계 " +(stepIndex+1)+ " 검색 영역 저장");
                            } else {
                                Bitmap crop=Bitmap.createBitmap(selectionBitmap,rect.left,rect.top,rect.width(),rect.height());
                                try {
                                    java.io.File dir=new java.io.File(getFilesDir(),"templates");dir.mkdirs();
                                    java.io.File file=java.io.File.createTempFile("step-",".png",dir);
                                    try(java.io.FileOutputStream out=new java.io.FileOutputStream(file)) {
                                        if(!crop.compress(Bitmap.CompressFormat.PNG,100,out))throw new java.io.IOException();
                                    }
                                    try { TemplateStore.add(OverlayService.this,android.net.Uri.fromFile(file)); }
                                    finally {file.delete();}
                                    images=TemplateStore.list(OverlayService.this);addLog("이미지 추가 완료 · 총 " + images.size() + "단계");
                                } finally {if(crop!=selectionBitmap)crop.recycle();}
                            }
                        } catch(Exception e) {toast("저장 실패: " + e.getClass().getSimpleName());}
                        releaseSelection();updateCounters();
                    }
                    public void cancelled() {releaseSelection();}
                });
            } catch(Exception e) {releaseSelection();toast("영역 선택창을 열 수 없습니다");}
        },300);
    }
    private void releaseSelection() {
        if(selector!=null) {selector.dismiss();selector=null;}
        if(selectionBitmap!=null) {selectionBitmap.recycle();selectionBitmap=null;}
        selecting=false;panel.setVisibility(View.VISIBLE);
    }

    private void stopRun() {
        looping = false;
        stepStarted=0;
        generation++;
        if (searchJob != null) searchJob.cancel(true);
        busy = false;
        handler.removeCallbacksAndMessages(null);
        if (panel != null) panel.setVisibility(View.VISIBLE);
    }

    private void applySettings() {
        threshold = (70 + accuracy.getProgress()) / 100.0;
        getSharedPreferences("macro", 0).edit()
            .putString("interval", intervalInput.getText().toString())
            .putString("repeat", repeatInput.getText().toString())
            .putInt("accuracy", 70 + accuracy.getProgress()).apply();
        intervalInput.clearFocus(); repeatInput.clearFocus();
        WindowManager.LayoutParams layout = (WindowManager.LayoutParams)panel.getLayoutParams();
        layout.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wm.updateViewLayout(panel, layout);
        try {
            intervalMs = Math.max(200L, Long.parseLong(intervalInput.getText().toString().trim()));
        } catch (Exception e) {
            intervalMs = 1300L;
            intervalInput.setText("1300");
        }

        try {
            repeatLimit = Math.max(0, Integer.parseInt(repeatInput.getText().toString().trim()));
        } catch (Exception e) {
            repeatLimit = 0;
            repeatInput.setText("0");
        }
    }

    private void startLoop() {
        if (busy || looping || selecting) return;
        applySettings();
        images = TemplateStore.list(this);

        if (!ScreenCaptureService.isReady()) {
            toast("화면 캡처 권한을 먼저 시작하세요.");
            addLog("실패: 화면 캡처 서비스 꺼짐");
            return;
        }
        if (!MacroAccessibilityService.isReady()) {
            toast("접근성 서비스를 먼저 켜세요.");
            addLog("실패: 접근성 서비스 꺼짐");
            return;
        }
        if (images.isEmpty()) {
            toast("찾을 이미지를 먼저 선택하세요.");
            addLog("실패: 찾을 이미지 없음");
            return;
        }

        generation++;
        stepStarted = 0;
        stepIndex = cycles = 0;
        executed = 0;
        successCount = 0;
        failCount = 0;
        looping = true;
        handler.removeCallbacks(loopTask);
        addLog(repeatLimit == 0
                ? "무한 반복 시작 / 간격 " + intervalMs + "ms"
                : "반복 " + repeatLimit + "회 시작 / 간격 " + intervalMs + "ms");
        handler.post(loopTask);
    }

    private void scanOnce(boolean fromLoop) {
        if (busy) return;
        if (!ScreenCaptureService.isReady() || !MacroAccessibilityService.isReady() || images.isEmpty()) {
            stopRun();
            addLog("중지: 화면 공유·접근성·등록 이미지를 확인하세요");
            updateCounters(); return;
        }
        busy = true;
        updateCounters();
        final int token = generation;
        final android.net.Uri uri = images.get(stepIndex);
        activeStep = StepSettings.load(this, uri);
        final StepSettings config = activeStep;
        if (stepStarted == 0) stepStarted = android.os.SystemClock.elapsedRealtime();
        if (android.os.SystemClock.elapsedRealtime()-stepStarted >= config.timeoutMs) {
            stopRun(); stepStarted=0; addLog("검색 제한시간 초과 · 정지"); updateCounters(); return;
        }
        final double matchThreshold = config.accuracy / 100.0;
        timeoutTask = () -> {
            if (token != generation) return;
            stopRun();addLog("검색 제한시간 초과 · 정지");updateCounters();
        };
        handler.postDelayed(timeoutTask, Math.max(1, config.timeoutMs - (android.os.SystemClock.elapsedRealtime()-stepStarted)));
        panel.setVisibility(View.INVISIBLE);
        // Discard the frame captured while the panel was visible, then wait for a fresh frame.
        Bitmap stale = ScreenCaptureService.latestBitmap();
        if (stale != null) stale.recycle();
        handler.postDelayed(() -> {
            if (token != generation) return;
            searchJob = worker.submit(() -> {
                Bitmap screen = null, templ = null;
                Point point = null;
                String error = null;
                try {
                    screen = ScreenCaptureService.latestBitmap();
                    // Show stop controls after obtaining a panel-free frame.
                    handler.post(() -> {if(token==generation)panel.setVisibility(View.VISIBLE);});
                    templ = TemplateStore.load(this, uri);
                    if (screen == null) error = "새 화면 대기 중";
                    else if (templ == null) error = "이미지를 다시 등록하세요";
                    else {
                        android.graphics.Rect bounds=config.bounds(screen.getWidth(),screen.getHeight());
                        Bitmap region=Bitmap.createBitmap(screen,bounds.left,bounds.top,bounds.width(),bounds.height());
                        try {
                            point=ImageMatcher.find(region,templ,matchThreshold);
                            if(point!=null) {point.x+=bounds.left;point.y+=bounds.top;}
                        } finally {if(region!=screen) region.recycle();}
                    }
                } catch (Exception e) { error = "검색 오류: " + e.getClass().getSimpleName(); }
                finally {
                    if (screen != null) screen.recycle();
                    if (templ != null) templ.recycle();
                }
                final Point found = point;
                final String reason = error;
                handler.post(() -> {
                    if (token != generation) return;
                    if (android.os.SystemClock.elapsedRealtime()-stepStarted >= config.timeoutMs) {
                        stopRun();stepStarted=0;addLog("검색 제한시간 초과 · 정지");updateCounters();return;
                    }
                    if (found == null) { finishScan(false, reason == null ? "이미지 미발견 · 현재 단계 재시도" : reason, fromLoop, token); return; }
                    panel.setVisibility(View.INVISIBLE);
                    handler.postDelayed(() -> {
                    if(token!=generation)return;
                    boolean accepted = MacroAccessibilityService.tap(found.x, found.y,
                        new android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                            @Override public void onCompleted(android.accessibilityservice.GestureDescription gesture) {
                                finishScan(true, "터치 완료 (" + found.x + ", " + found.y + ")", fromLoop, token);
                            }
                            @Override public void onCancelled(android.accessibilityservice.GestureDescription gesture) {
                                finishScan(false, "터치 취소", fromLoop, token);
                            }
                        });
                    if (!accepted) finishScan(false, "터치 요청 실패", fromLoop, token);
                    }, 100);
                });
            });
        }, 200);
    }

    private void finishScan(boolean success, String message, boolean fromLoop, int token) {
        if (token != generation || !busy) return;
        busy = false;
        if(timeoutTask!=null) handler.removeCallbacks(timeoutTask);
        panel.setVisibility(View.VISIBLE);
        executed++;
        addLog("단계 " + (stepIndex+1) + " · " + (success ? "성공: " : "실패: ") + message);
        if (success) {
            successCount++;
            stepStarted=0;
            stepIndex++;
            if (stepIndex == images.size()) { stepIndex = 0; cycles++; }
        } else failCount++;
        if (fromLoop && repeatLimit > 0 && cycles >= repeatLimit) {
            looping = false;
            addLog("전체 순서 " + cycles + "회 완료");
        }
        updateCounters();
        if (fromLoop && looping) handler.postDelayed(loopTask, success && activeStep!=null ? activeStep.waitMs : intervalMs);
    }

    private final Runnable loopTask = new Runnable() {
        @Override public void run() {
            if (!looping) return;
            scanOnce(true);
        }
    };

    private void updateCounters() {
        if (compactStatus!=null) compactStatus.setText((looping||busy ? "실행 중" : "정지") + " · "
            + (images.isEmpty()?0:stepIndex+1) + "/" + images.size()+" · 완료 "+cycles+"회");
        if (counterView == null) return;
        String mode = repeatLimit == 0 ? "무한" : String.valueOf(repeatLimit);
        counterView.setText(
                "상태: " + (looping ? "실행 중" : "정지") +
                " | 반복: " + mode +
                "\n단계 " + (stepIndex+1) + "/" + images.size() + " · 완료 " + cycles + "회" +
                "\n검색 " + executed +
                " / 성공 " + successCount +
                " / 실패 " + failCount
        );
    }

    private void addLog(String msg) {
        if (logView == null) return;
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String old = logView.getText().toString();
        String line = "[" + time + "] " + msg;
        String combined = line + (old.isEmpty() ? "" : "\n" + old);

        String[] lines = combined.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 8);
        for (int i=0; i<max; i++) {
            if (i>0) sb.append("\n");
            sb.append(lines[i]);
        }
        logView.setText(sb.toString());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        stopRun();
        releaseSelection();
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        worker.shutdownNow();
        if(instance==this)instance=null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
