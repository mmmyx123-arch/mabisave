package com.mabisave.automacro;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {

    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_DATA = "data";
    private static final int NOTIFY_ID = 101;
    private static final String CHANNEL = "capture";

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;

    private static ScreenCaptureService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        nb.setContentTitle("MabiSave 화면 검색")
          .setContentText("이미지 검색을 위해 화면을 읽는 중")
          .setSmallIcon(android.R.drawable.ic_menu_view);

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFY_ID, nb.build(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFY_ID, nb.build());
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "화면 검색", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (projection != null) return START_NOT_STICKY;
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra(EXTRA_DATA, Intent.class);
        } else {
            data = intent.getParcelableExtra(EXTRA_DATA);
        }
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mpm =
                (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, new android.os.Handler(android.os.Looper.getMainLooper()));
        setupCapture();
        return START_NOT_STICKY;
    }

    private void setupCapture() {
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int width, height;
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            width = bounds.width(); height = bounds.height();
        } else {
            wm.getDefaultDisplay().getRealMetrics(dm);
            width = dm.widthPixels; height = dm.heightPixels;
        }
        int dpi = dm.densityDpi;

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);

        display = projection.createVirtualDisplay(
                "MabiSaveCapture",
                width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, null
        );
    }

    public static boolean isReady() {
        return instance != null && instance.projection != null;
    }

    public static Bitmap latestBitmap() {
        if (instance == null || instance.reader == null) return null;
        Image image = null;
        try {
            image = instance.reader.acquireLatestImage();
            if (image == null) return null;

            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * image.getWidth();

            Bitmap full = Bitmap.createBitmap(
                    image.getWidth() + rowPadding / pixelStride,
                    image.getHeight(),
                    Bitmap.Config.ARGB_8888
            );
            full.copyPixelsFromBuffer(buffer);

            Bitmap cropped = Bitmap.createBitmap(full, 0, 0,
                    image.getWidth(), image.getHeight());
            if (cropped != full) full.recycle();
            return cropped;
        } catch (Exception e) {
            return null;
        } finally {
            if (image != null) image.close();
        }
    }

    @Override
    public void onDestroy() {
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
