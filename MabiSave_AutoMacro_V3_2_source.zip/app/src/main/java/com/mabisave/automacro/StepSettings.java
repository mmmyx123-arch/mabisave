package com.mabisave.automacro;

import android.content.Context;
import android.net.Uri;
import android.graphics.Rect;
import org.json.JSONObject;

public final class StepSettings {
    public int accuracy = 86;
    public long waitMs = 1300, timeoutMs = 30000;
    public float left = 0, top = 0, right = 1, bottom = 1;
    private static String key(Uri uri) { return "step:" + uri.toString(); }
    public static StepSettings load(Context c, Uri uri) {
        StepSettings s = new StepSettings();
        try {
            JSONObject o = new JSONObject(c.getSharedPreferences("macro",0).getString(key(uri),"{}"));
            s.accuracy = o.optInt("accuracy",86);
            s.waitMs = o.optLong("wait",1300);
            s.timeoutMs = o.optLong("timeout",30000);
            s.left = (float)o.optDouble("left",0); s.top = (float)o.optDouble("top",0);
            s.right = (float)o.optDouble("right",1); s.bottom = (float)o.optDouble("bottom",1);
        } catch (Exception ignored) {}
        return s;
    }
    public void save(Context c, Uri uri) {
        try {
            JSONObject o = new JSONObject();
            o.put("accuracy",accuracy).put("wait",waitMs).put("timeout",timeoutMs)
             .put("left",left).put("top",top).put("right",right).put("bottom",bottom);
            c.getSharedPreferences("macro",0).edit().putString(key(uri),o.toString()).apply();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    public Rect bounds(int w, int h) {
        return new Rect(Math.max(0,Math.min(w-1,(int)(left*w))), Math.max(0,Math.min(h-1,(int)(top*h))),
            Math.max(1,Math.min(w,(int)Math.ceil(right*w))), Math.max(1,Math.min(h,(int)Math.ceil(bottom*h))));
    }
}
