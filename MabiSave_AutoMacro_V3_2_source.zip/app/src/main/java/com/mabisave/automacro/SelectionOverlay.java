package com.mabisave.automacro;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.*;

/** Shows a frozen screenshot and converts drag coordinates to source bitmap pixels. */
public final class SelectionOverlay {
    public interface Result { void selected(Rect rect); void cancelled(); }
    private final WindowManager wm;
    private final FrameLayout root;
    private boolean closed;
    private final Bitmap bitmap;
    private final Result callback;
    public SelectionOverlay(Context c, Bitmap image, String title, Result result) {
        bitmap = image; callback = result;
        wm = (WindowManager)c.getSystemService(Context.WINDOW_SERVICE);
        root = new FrameLayout(c);
        final Selector selector = new Selector(c);
        root.addView(selector, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.VERTICAL); bar.setBackgroundColor(0xE6202124);
        TextView help = new TextView(c); help.setText(title + " · 드래그 후 저장"); help.setTextColor(Color.WHITE);
        bar.addView(help);
        LinearLayout buttons = new LinearLayout(c);
        Button save = new Button(c); save.setText("선택 저장");
        Button cancel = new Button(c); cancel.setText("취소");
        buttons.addView(save); buttons.addView(cancel); bar.addView(buttons);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        root.addView(bar,bp);
        Button move = new Button(c); move.setText("메뉴 위/아래"); buttons.addView(move);
        move.setOnClickListener(v -> {
            bp.gravity = bp.gravity==Gravity.BOTTOM ? Gravity.TOP : Gravity.BOTTOM;
            bar.setLayoutParams(bp);
        });
        save.setOnClickListener(v -> {
            Rect r = selector.selection();
            if (r.width()<4 || r.height()<4) { Toast.makeText(c,"4픽셀 이상 영역을 드래그하세요",0).show(); return; }
            dismiss(); callback.selected(r);
        });
        cancel.setOnClickListener(v -> { dismiss(); callback.cancelled(); });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1,-1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(root,lp);
    }
    public void dismiss() { if (!closed) { closed=true; wm.removeView(root); } }
    private final class Selector extends View {
        final Paint paint = new Paint();
        final RectF selected = new RectF();
        float startX,startY,scale=1,dx,dy;
        Selector(Context c) { super(c); }
        @Override protected void onDraw(Canvas canvas) {
            canvas.drawColor(Color.BLACK);
            scale=Math.min(getWidth()/(float)bitmap.getWidth(),getHeight()/(float)bitmap.getHeight());
            dx=(getWidth()-bitmap.getWidth()*scale)/2; dy=(getHeight()-bitmap.getHeight()*scale)/2;
            canvas.drawBitmap(bitmap,null,new RectF(dx,dy,dx+bitmap.getWidth()*scale,dy+bitmap.getHeight()*scale),null);
            paint.setColor(0x4433CCFF); paint.setStyle(Paint.Style.FILL); canvas.drawRect(selected,paint);
            paint.setColor(Color.CYAN); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3); canvas.drawRect(selected,paint);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=Math.max(dx,Math.min(dx+bitmap.getWidth()*scale,e.getX()));
            float y=Math.max(dy,Math.min(dy+bitmap.getHeight()*scale,e.getY()));
            if(e.getAction()==MotionEvent.ACTION_DOWN) { startX=x;startY=y; }
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE || e.getAction()==MotionEvent.ACTION_UP) {
                selected.set(Math.min(startX,x),Math.min(startY,y),Math.max(startX,x),Math.max(startY,y)); invalidate();
            }
            return true;
        }
        Rect selection() {
            return new Rect(Math.max(0,(int)((selected.left-dx)/scale)),Math.max(0,(int)((selected.top-dy)/scale)),
                Math.min(bitmap.getWidth(),(int)((selected.right-dx)/scale)),Math.min(bitmap.getHeight(),(int)((selected.bottom-dy)/scale)));
        }
    }
}
