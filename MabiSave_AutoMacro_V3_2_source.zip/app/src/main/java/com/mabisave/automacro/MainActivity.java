package com.mabisave.automacro;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 100;
    private static final int REQ_IMAGE = 101;

    private MediaProjectionManager projectionManager;
    private TextView status;
    private LinearLayout imageList;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("MabiSave 매크로 3.4");
        title.setTextSize(25);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText(
                "\n기능\n" +
                "• 다른 앱 위 플로팅 버튼\n" +
                "• 등록 순서대로 이미지 검색\n" +
                "• 찾은 이미지 중심 자동 탭\n" +
                "• 정확도 조절 · 반복 실행 · 로그\n"
        );
        root.addView(desc);

        Button access = btn("1. 접근성 서비스 켜기");
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button overlay = btn("2. 다른 앱 위에 표시 권한");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                Toast.makeText(this, "이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(overlay);

        Button select = btn("3. 순서에 추가할 이미지 선택");
        select.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_IMAGE);
        });
        root.addView(select);

        Button savePreset=btn("현재 작업을 프리셋으로 저장");
        savePreset.setOnClickListener(v -> savePreset());root.addView(savePreset);
        Button loadPreset=btn("프리셋 불러오기 / 삭제");
        loadPreset.setOnClickListener(v -> choosePreset());root.addView(loadPreset);
        imageList = new LinearLayout(this);
        imageList.setOrientation(LinearLayout.VERTICAL);
        root.addView(imageList);
        TextView sequenceTip = new TextView(this);
        sequenceTip.setText("이미지를 한 장씩 추가하세요. 1번 터치 완료 후 2번을 찾습니다.\n미발견 시 현재 단계를 재시도합니다. 반복 횟수는 전체 순서 완료 기준입니다.");
        root.addView(sequenceTip);

        Button capture = btn("4. 화면 검색 권한 시작");
        capture.setOnClickListener(v -> {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        root.addView(capture);

        Button floatBtn = btn("5. 플로팅 매크로 띄우기");
        floatBtn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
                return;
            }
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "플로팅 버튼을 띄웠습니다.", Toast.LENGTH_SHORT).show();
        });
        root.addView(floatBtn);

        Button stopCapture = btn("화면 검색 서비스 종료");
        stopCapture.setOnClickListener(v ->
                stopService(new Intent(this, ScreenCaptureService.class)));
        root.addView(stopCapture);

        status = new TextView(this);
        status.setPadding(0, dp(14), 0, dp(8));
        root.addView(status);

        TextView tip = new TextView(this);
        tip.setText(
                "사용법:\n" +
                "1) 찾고 싶은 버튼/아이콘을 캡처한 이미지로 저장\n" +
                "2) 위 순서대로 권한 허용\n" +
                "3) 플로팅 매크로 띄우기\n" +
                "4) 대상 앱으로 이동\n" +
                "5) '이미지 찾기' 또는 '반복 시작'\n\n" +
                "주의: 다른 앱을 터치하려면 화면 공유에서 전체 화면을 선택하세요. 검색 대상 앱의 방향을 고정하고 시작하세요."
        );
        root.addView(tip);

        setContentView(sv);
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        imageList.removeAllViews();
        java.util.List<Uri> images = TemplateStore.list(this);
        for (int n=0; n<images.size(); n++) {
            final int index = n;
            LinearLayout row = new LinearLayout(this);
            ImageView preview = new ImageView(this);
            preview.setImageURI(images.get(n));
            preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(preview, new LinearLayout.LayoutParams(dp(48), dp(48)));
            TextView label = new TextView(this); label.setText("단계 " + (n+1));
            row.addView(label, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button up = btn("↑"); up.setEnabled(n>0);
            up.setOnClickListener(v -> { java.util.Collections.swap(images,index,index-1); TemplateStore.save(this,images); updateStatus(); });
            row.addView(up, new LinearLayout.LayoutParams(dp(55), dp(48)));
            Button remove = btn("삭제");
            remove.setOnClickListener(v -> { images.remove(index); TemplateStore.save(this,images); updateStatus(); });
            row.addView(remove, new LinearLayout.LayoutParams(dp(70), dp(48)));
            imageList.addView(row);
            Button configure = btn("단계 " + (n+1) + " 설정 · 정확도 / 대기 / 검색 영역");
            configure.setOnClickListener(v -> editStep(images.get(index)));
            imageList.addView(configure);
        }
        status.setText(
                "접근성: " + (MacroAccessibilityService.isReady() ? "연결됨" : "꺼짐") +
                "\n다른 앱 위 표시: " + (Settings.canDrawOverlays(this) ? "허용됨" : "허용 안 됨") +
                "\n찾을 이미지: " + (!TemplateStore.list(this).isEmpty() ? TemplateStore.list(this).size() + "개 등록" : "미선택") +
                "\n화면 검색: " + (ScreenCaptureService.isReady() ? "실행 중" : "정지")
        );
    }

    private boolean presetReady() {
        if(OverlayService.isActive()) {Toast.makeText(this,"매크로를 정지하고 영역 선택을 닫은 뒤 사용하세요",0).show();return false;}
        return true;
    }
    private void savePreset() {
        if(!presetReady())return;
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("예: 일일 작업");
        name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("프리셋 이름").setView(name)
            .setNegativeButton("취소",null).setPositiveButton("저장",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value=name.getText().toString().trim();
            if(value.isEmpty()) {name.setError("이름을 입력하세요");return;}
            if(!presetReady())return;
            Runnable save=() -> {
                if(!presetReady())return;
                try {OverlayService.saveIdleSettings();PresetStore.save(this,value);dialog.dismiss();Toast.makeText(this,"프리셋 저장 완료",0).show();}
                catch(Exception e) {Toast.makeText(this,e.getMessage(),0).show();}
            };
            if(PresetStore.exists(this,value))new AlertDialog.Builder(this).setMessage("같은 이름의 프리셋을 덮어쓸까요?")
                .setNegativeButton("취소",null).setPositiveButton("덮어쓰기",(a,b)->save.run()).show();
            else save.run();
        }));dialog.show();
    }
    private void choosePreset() {
        if(!presetReady())return;
        java.util.List<String> names=PresetStore.names(this);
        if(names.isEmpty()) {Toast.makeText(this,"저장된 프리셋이 없습니다",0).show();return;}
        new AlertDialog.Builder(this).setTitle("저장된 프리셋").setItems(names.toArray(new String[0]),(d,n)->{
            String name=names.get(n);
            new AlertDialog.Builder(this).setTitle(name).setMessage("불러오면 현재 이미지 순서와 설정을 교체합니다. 저장하지 않은 변경은 사라집니다.")
                .setPositiveButton("불러오기",(a,b)->{
                    if(!presetReady())return;
                    try {PresetStore.load(this,name);OverlayService.reloadPreset();updateStatus();Toast.makeText(this,"불러오기 완료 · 실행은 시작 버튼을 누르세요",0).show();}
                    catch(Exception e) {Toast.makeText(this,e.getMessage(),0).show();}
                }).setNeutralButton("삭제",(a,b)->new AlertDialog.Builder(this).setMessage(name+" 프리셋을 삭제할까요?")
                    .setNegativeButton("취소",null).setPositiveButton("삭제",(x,y)->{
                        try {PresetStore.delete(this,name);Toast.makeText(this,"프리셋 삭제 완료",0).show();}
                        catch(Exception e) {Toast.makeText(this,e.getMessage(),0).show();}
                    }).show()).setNegativeButton("취소",null).show();
        }).setNegativeButton("닫기",null).show();
    }

    private EditText number(LinearLayout box, String title, String value) {
        TextView label=new TextView(this); label.setText(title); box.addView(label);
        EditText e=new EditText(this); e.setSingleLine(true);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(value); box.addView(e); return e;
    }
    private void editStep(Uri uri) {
        StepSettings settings=StepSettings.load(this,uri);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0);
        EditText accuracy=number(box,"정확도 % (70~100)",""+settings.accuracy);
        EditText wait=number(box,"터치 후 대기 ms (200~60000)",""+settings.waitMs);
        EditText timeout=number(box,"검색 제한 ms (1000~600000, 초과 시 정지)",""+settings.timeoutMs);
        EditText left=number(box,"검색 영역 왼쪽 %",""+(settings.left*100));
        EditText top=number(box,"검색 영역 위 %",""+(settings.top*100));
        EditText right=number(box,"검색 영역 오른쪽 %",""+(settings.right*100));
        EditText bottom=number(box,"검색 영역 아래 %",""+(settings.bottom*100));
        TextView tip=new TextView(this); tip.setText("기본 0 / 0 / 100 / 100 = 전체 화면. 플로팅 패널의 ‘검색 영역 지정’으로 직접 그릴 수도 있습니다."); box.addView(tip);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("단계 설정").setView(scroll)
            .setPositiveButton("저장",null).setNegativeButton("취소",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                int a=Integer.parseInt(accuracy.getText().toString());
                long w=Long.parseLong(wait.getText().toString()),t=Long.parseLong(timeout.getText().toString());
                float l=Float.parseFloat(left.getText().toString()),u=Float.parseFloat(top.getText().toString()),r=Float.parseFloat(right.getText().toString()),b=Float.parseFloat(bottom.getText().toString());
                if(a<70||a>100||w<200||w>60000||t<1000||t>600000 || !(l>=0&&u>=0&&r<=100&&b<=100&&l<r&&u<b)) throw new IllegalArgumentException();
                settings.accuracy=a;settings.waitMs=w;settings.timeoutMs=t;
                settings.left=l/100;settings.top=u/100;settings.right=r/100;settings.bottom=b/100;
                settings.save(this,uri);dialog.dismiss();
            } catch(Exception e) { Toast.makeText(this,"입력 범위와 영역 순서를 확인하세요",0).show(); }
        })); dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                try {
                    TemplateStore.add(this, uri);
                    Toast.makeText(this, "이미지를 순서에 추가했습니다.", Toast.LENGTH_SHORT).show();
                } catch(Exception e) { Toast.makeText(this,"이미지 저장 실패 · 32MB 이하 파일을 선택하세요",0).show(); }
            }
            updateStatus();
            return;
        }

        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, ScreenCaptureService.class);
            svc.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
            svc.putExtra(ScreenCaptureService.EXTRA_DATA, data);

            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
            else startService(svc);

            new Handler(Looper.getMainLooper()).postDelayed(this::updateStatus, 700);
        }
    }
}
