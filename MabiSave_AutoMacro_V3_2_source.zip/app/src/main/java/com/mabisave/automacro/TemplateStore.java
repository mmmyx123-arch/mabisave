package com.mabisave.automacro;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import org.json.JSONArray;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public final class TemplateStore {
    private TemplateStore() {}
    public static List<Uri> list(Context c) {
        List<Uri> result = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences("macro", 0).getString("images", "[]"));
            for (int i=0; i<a.length(); i++) result.add(Uri.parse(a.getString(i)));
        } catch (Exception ignored) {}
        return result;
    }
    public static void add(Context c, Uri uri) {
        java.io.File copied = null;
        try {
            java.io.File dir = new java.io.File(c.getFilesDir(), "templates"); dir.mkdirs();
            copied = java.io.File.createTempFile("registered-", ".img", dir);
            try (InputStream in = c.getContentResolver().openInputStream(uri);
                 java.io.FileOutputStream out = new java.io.FileOutputStream(copied)) {
                if (in == null) throw new java.io.IOException();
                byte[] buffer = new byte[8192]; int count; long total=0;
                while((count=in.read(buffer))!=-1) {
                    total+=count; if(total>32*1024*1024) throw new java.io.IOException("이미지는 32MB 이하로 선택하세요");
                    out.write(buffer,0,count);
                }
            }
            List<Uri> images = list(c); images.add(Uri.fromFile(copied)); save(c, images);
        } catch (Exception e) {
            if(copied!=null) copied.delete();
            throw new IllegalArgumentException("이미지 저장 실패", e);
        }
    }
    public static void save(Context c, List<Uri> images) {
        JSONArray a = new JSONArray();
        for (Uri uri : images) a.put(uri.toString());
        c.getSharedPreferences("macro", 0).edit().putString("images", a.toString()).apply();
    }
    public static Bitmap load(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, opts);
            if (opts.outWidth < 4 || opts.outHeight < 4 || (long)opts.outWidth * opts.outHeight > 16000000L) return null;
        } catch (Exception e) { return null; }
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) { return null; }
    }
}
