package com.mabisave.automacro;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import org.json.JSONArray;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public final class TemplateStore {
    private TemplateStore() {}
    public static List<Uri> list(Context c) {
        List<Uri> result = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences("macro", 0).getString("images", "[]"));
            for (int i=0; i<a.length(); i++) result.add(Uri.parse(a.getString(i)));
        } catch (Exception ignored) {}
        return result;
    }
    public static void add(Context c, Uri uri) {
        List<Uri> images = list(c); images.add(uri); save(c, images);
    }
    public static void save(Context c, List<Uri> images) {
        JSONArray a = new JSONArray();
        for (Uri uri : images) a.put(uri.toString());
        c.getSharedPreferences("macro", 0).edit().putString("images", a.toString()).apply();
    }
    public static Bitmap load(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, opts);
            if (opts.outWidth < 4 || opts.outHeight < 4 || (long)opts.outWidth * opts.outHeight > 16000000L) return null;
        } catch (Exception e) { return null; }
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) { return null; }
    }
}
