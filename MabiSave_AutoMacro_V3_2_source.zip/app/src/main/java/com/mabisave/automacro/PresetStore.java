package com.mabisave.automacro;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.*;
import java.util.*;

/** Presets snapshot settings; immutable private template files are shared safely. */
public final class PresetStore {
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("presets",0); }
    public static List<String> names(Context c) {
        List<String> names = new ArrayList<>(prefs(c).getAll().keySet());
        Collections.sort(names);return names;
    }
    public static boolean exists(Context c,String name) {return prefs(c).contains(name);}
    public static void save(Context c,String name) throws Exception {
        name=name.trim();
        if(name.isEmpty() || name.length()>40) throw new Exception("이름은 1~40자로 입력하세요");
        List<Uri> images=TemplateStore.list(c);
        if(images.isEmpty()) throw new Exception("이미지를 먼저 등록하세요");
        SharedPreferences active=c.getSharedPreferences("macro",0);
        JSONArray steps=new JSONArray();
        for(Uri uri:images) {
            JSONObject step=new JSONObject();step.put("uri",uri.toString());
            step.put("config",new JSONObject(active.getString("step:"+uri.toString(),"{}")));
            steps.put(step);
        }
        JSONObject preset=new JSONObject().put("version",1).put("steps",steps)
            .put("interval",active.getString("interval","1300"))
            .put("repeat",active.getString("repeat","0"));
        if(!prefs(c).edit().putString(name,preset.toString()).commit()) throw new Exception("저장 공간을 확인하세요");
    }
    public static void load(Context c,String name) throws Exception {
        String raw=prefs(c).getString(name,null);
        if(raw==null) throw new Exception("프리셋을 찾을 수 없습니다");
        JSONObject preset=new JSONObject(raw);
        if(preset.getInt("version")!=1) throw new Exception("지원하지 않는 프리셋 버전입니다");
        JSONArray steps=preset.getJSONArray("steps"),images=new JSONArray();
        if(steps.length()==0)throw new Exception("빈 프리셋입니다");
        SharedPreferences.Editor edit=c.getSharedPreferences("macro",0).edit();
        for(int n=0;n<steps.length();n++) {
            JSONObject step=steps.getJSONObject(n);String value=step.getString("uri");
            try(java.io.InputStream in=c.getContentResolver().openInputStream(Uri.parse(value))) {
                if(in==null || in.read()==-1)throw new Exception("프리셋 이미지가 없거나 읽을 수 없습니다");
            }
            images.put(value);edit.putString("step:"+value,step.getJSONObject("config").toString());
        }
        edit.putString("images",images.toString()).putString("interval",preset.getString("interval"))
            .putString("repeat",preset.getString("repeat"));
        if(!edit.commit())throw new Exception("프리셋을 적용하지 못했습니다");
    }
    public static void delete(Context c,String name) throws Exception {
        if(!prefs(c).edit().remove(name).commit())throw new Exception("삭제하지 못했습니다");
    }
}
