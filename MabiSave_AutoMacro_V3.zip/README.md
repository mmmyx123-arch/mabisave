# MabiSave Auto Macro v3

추가 기능
- 이미지 검색
- 다른 앱 위 플로팅 패널
- 검색 간격 직접 조절(ms)
- 반복 횟수 직접 지정
- 0 입력 시 무한 반복
- 성공/실패/총 실행 횟수 표시
- 성공/실패 실시간 로그
- 로그/카운트 초기화
- 일시정지
- 찾은 이미지 중심 자동 탭

## GitHub 빌드
기존 ZIP 교체 후 workflow의 unzip 파일명을
`MabiSave_AutoMacro_V3.zip` 으로 바꾸면 됩니다.
