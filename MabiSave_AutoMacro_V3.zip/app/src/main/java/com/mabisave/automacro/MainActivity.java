package com.mabisave.automacro;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 100;
    private static final int REQ_IMAGE = 101;

    private MediaProjectionManager projectionManager;
    private TextView status;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("MabiSave Auto Macro v2");
        title.setTextSize(25);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText(
                "\n기능\n" +
                "• 다른 앱 위 플로팅 버튼\n" +
                "• 선택한 이미지 화면 검색\n" +
                "• 찾은 이미지 중심 자동 탭\n" +
                "• 반복 검색\n"
        );
        root.addView(desc);

        Button access = btn("1. 접근성 서비스 켜기");
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button overlay = btn("2. 다른 앱 위에 표시 권한");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                Toast.makeText(this, "이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(overlay);

        Button select = btn("3. 찾을 이미지 선택");
        select.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_IMAGE);
        });
        root.addView(select);

        Button capture = btn("4. 화면 검색 권한 시작");
        capture.setOnClickListener(v -> {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        root.addView(capture);

        Button floatBtn = btn("5. 플로팅 매크로 띄우기");
        floatBtn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
                return;
            }
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "플로팅 버튼을 띄웠습니다.", Toast.LENGTH_SHORT).show();
        });
        root.addView(floatBtn);

        Button stopCapture = btn("화면 검색 서비스 종료");
        stopCapture.setOnClickListener(v ->
                stopService(new Intent(this, ScreenCaptureService.class)));
        root.addView(stopCapture);

        status = new TextView(this);
        status.setPadding(0, dp(14), 0, dp(8));
        root.addView(status);

        TextView tip = new TextView(this);
        tip.setText(
                "사용법:\n" +
                "1) 찾고 싶은 버튼/아이콘을 캡처한 이미지로 저장\n" +
                "2) 위 순서대로 권한 허용\n" +
                "3) 플로팅 매크로 띄우기\n" +
                "4) 대상 앱으로 이동\n" +
                "5) '이미지 찾기' 또는 '반복 시작'\n\n" +
                "주의: 화면 캡처 권한은 Android가 직접 확인창을 띄우며, 앱이 임의로 우회하지 않습니다."
        );
        root.addView(tip);

        setContentView(sv);
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(
                "접근성: " + (MacroAccessibilityService.isReady() ? "연결됨" : "꺼짐") +
                "\n다른 앱 위 표시: " + (Settings.canDrawOverlays(this) ? "허용됨" : "허용 안 됨") +
                "\n찾을 이미지: " + (TemplateStore.getUri() != null ? "선택됨" : "미선택") +
                "\n화면 검색: " + (ScreenCaptureService.isReady() ? "실행 중" : "정지")
        );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                TemplateStore.setUri(uri);
                Toast.makeText(this, "찾을 이미지를 선택했습니다.", Toast.LENGTH_SHORT).show();
            }
            updateStatus();
            return;
        }

        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, ScreenCaptureService.class);
            svc.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
            svc.putExtra(ScreenCaptureService.EXTRA_DATA, data);

            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
            else startService(svc);

            new Handler(Looper.getMainLooper()).postDelayed(this::updateStatus, 700);
        }
    }
}
